<!DOCTYPE html>
<html lang="en">
<head>
    <title>Data Siswa</title>
    <!-- Latest compiled and minified CSS -->
    <style>
    .body{
    margin-top:70px;
    }
    </style>
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</head>
<body>
    <div class="container">
    <header >
    <!-- Fixed navbar -->
    <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-success">
    <div class="container-fluid">
    <a class="navbar-brand" href="#">AppSiswa</a>
    <button class="navbar-toggler" type="button"
    data-bs-toggle="collapse" data-bs-target="#navbarCollapse"
    aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle
    navigation">
    <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarCollapse">
    <ul class="navbar-nav me-auto mb-2 mb-md-0">
    <li class="nav-item">
    <a class="nav-link" href="<?=site_url();?>">Home</a>
    </li>
    <li class="nav-item">
    <!--<div class="dropdown">
  <a class="btn btn-secondary dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
    Data
  </a>

  <ul class="dropdown-menu">
    <li><a class="dropdown-item" href="<?=site_url('list-siswa');?>">Action</a></li>
    <li><a class="dropdown-item" href="#">Another action</a></li>
    <li><a class="dropdown-item" href="#">Something else here</a></li> 
  </ul>
</div> -->
<a class="nav-link" href="<?=site_url('list-siswa');?>">Data Siswa</a>
    </li>
    <li class="nav-item">
    <a class="nav-link"
    href="<?=site_url('tambah-siswa');?>">Tambah Siswa</a>
    </li>
    <li class="nav-item">
    <a class="nav-link" href="<?=site_url('cari-siswa');?>">Cari
    Siswa</a>
    </li>
    </ul>
    </div>
    </div>
    </nav>
    </header>
    <div class="body">
    <?php
    if(isset($judulHalaman)){
    echo $this->renderSection('konten');
    } else {
    echo '<div class="container my-5">
    <div class="p-5 text-center bg-body-tertiary rounded-3">
    <h1 class="text-body-emphasis">Aplikasi Data Siswa</h1>
    <p class="lead">
    Aplikasi ini merupakan contoh penggunaan Stored Procedure
    didalam database MySQL yang diimplementasikan pada framework CodeIgniter4.
    </p>
    </div>
    </div>';
    }
    ?>
    </div>
    </div>
</body>
</html>
